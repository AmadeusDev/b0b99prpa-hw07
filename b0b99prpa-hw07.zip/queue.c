#include "queue.h"

/* Queue structure which holds all necessary data */

queue_t* create_queue(int capacity)
{
	queue_t *q = (queue_t*)malloc(sizeof(queue_t));
	
	q->stack = (void**)malloc(sizeof(void*)*capacity);
	for (size_t i = 0; i < capacity; i++){
		q->stack[i] = 0;
	}

	q->maxSize = capacity;
	q->size = 0;
	q->fId = 0;
	return q;
}

void delete_queue(queue_t *queue)
{
	free(queue->stack);
	free(queue);
}

bool push_to_queue(queue_t *queue, void *data)
{
	if (queue->size >= queue->maxSize)
		return false;
	queue->stack[(queue->fId + queue->size)%queue->maxSize] = data;
	queue->size++;
	return true;

}

void* pop_from_queue(queue_t *queue)
{
	void *ret = 0;

	if (queue->size != 0)
	{
		ret = queue->stack[queue->fId];
		queue->fId++;
		queue->fId %= queue->maxSize;
		queue->size--;
	}

	return ret;
}

/*
 * gets idx-th element from the queue
 * returns the element that will be popped after idx calls of the pop_from_queue()
 * returns: the idx-th element on success; NULL otherwise
 */
void* get_from_queue(queue_t *queue, int idx)
{
	if (idx > 0)
	{
		if (idx < queue->maxSize)
			return queue->stack[((queue->fId) + idx) % queue->maxSize];

		return nullptr;
	}
	else
	{
		idx *= -1;
		if (idx <= queue->maxSize)
		{
			idx %= queue->maxSize;
			return queue->stack[((queue->maxSize + queue->fId) - idx) % queue->maxSize)];
		}
		return nullptr;
	}
}

/* gets number of stored elements */
int get_queue_size(queue_t *queue)
{

	return queue->size;
}
